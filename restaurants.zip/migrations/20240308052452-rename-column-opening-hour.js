'use strict';

const { QueryError } = require("sequelize");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    
  },

  down: async (queryInterface, Sequelize) => {
    
  }
};